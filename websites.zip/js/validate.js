	function validateForm()
	{
		var email =document.forms["myForm"]["email"].value;
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if(!email.match(mailformat))
		{
			alert("Invalid email");
		}
	
	    var password = document.forms["myForm"]["pass"].value;
		var psw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/;
		if(!password.match(psw))
		{
			alert("Password must contains 7 to 14 characters.It includes number and underscore");
	
		}
	
        var confirmpass = document.forms["myForm"]["confirmpassword"].value;
	    if(!confirmpass.match(password))
	   {
        alert("Password Mismatch");
	   }
	   if((email.match(mailformat)) && (password.match(psw)))
    {
    	alert("Your Registration is successfully completed");
    }
}

 



 

 



